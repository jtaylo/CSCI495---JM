﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/*
 * Resources Used
 * 
 * https://medium.freecodecamp.org/simple-chess-ai-step-by-step-1d55a9266977 this link lead to the link below 
 * https://chessprogramming.wikispaces.com/Simplified+evaluation+function is what I'm actually using
 * 
 */
namespace JMCapstone
{
    public class AI
    {
        
        int[,] BoardState;

        private int Eval()
        {
            int total = 0;
            int temp = 0;

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {

                    if (BoardState[i, j] != -1)
                    {
                        total += Constants.pointValues[BoardState[i, j]];

                        switch (BoardState[i, j])
                        {

                            case Constants.BlackRook:
                                
                                total += Constants.RookPositionVal[(63 - (8 * j) - (i - 7))];
                                Debug.Log(Constants.RookPositionVal[(63 - (8 * j) - (i - 7))]);

                                break;
                            case Constants.BlackKnight:

                                break;
                            case Constants.BlackBishop:

                                break;
                            case Constants.BlackKing:

                                break;
                            case Constants.BlackQueen:

                                break;
                            case Constants.BlackPawn:

                                break;                                
                        }
                    }
                    
                }
            }

            return total;

        }



            public int getMove()
        {

            return 1;
        }

        public void Update(int[,] boardState)
        {
            BoardState = boardState;
        }



    }
}


/*
        private int Eval()
        {
            int total = 0;

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (BoardState[i, j] != -1)
                    {
                        total +=  Constants.pointValues[BoardState[i, j]];

                    }

                }
            }

            return total;

            /*
            switch statement for each piece type



             



        }
        */
